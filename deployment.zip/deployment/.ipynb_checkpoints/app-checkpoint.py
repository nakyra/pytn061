from flask import Flask, request, render_template
import numpy as np
import pickle
model = pickle.load(open('models/random_forest.pkl', 'rb'))

app = Flask(__name__)

@app.route('/')
def sapa():
    return "Selamat malam"

@app.route('/pagi')
def pagi():
    return "Selamat pagi"

@app.route('/user/<nama>')
def user(nama):
    return "Selamat datang %s" % (nama)

@app.route('/post/<int:post_id>')
def post(post_id):
    return "Post %d" % (post_id)

@app.route('/dataset')
def showdata():
    return render_template('output.html')

@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        return do_login()
    else:
        return show_login_form()
    
def show_login_form():
    return render_template('login.html')

def do_login():
    return "thank you for logging in!"

@app.route('/predict', methods=['GET','POST'])
def predict():
    if request.method == "POST":
        vals = request.form.values()        
        int_features = [int(x) for x in vals]
        final_features = [np.array(int_features)]
        prediction = model.predict(final_features)

        output = {0: 'tidak dapat kerja', 1: 'dapat kerja'}

        return render_template('main.html', prediction_text='Murid ini {} di tempat kerja ini'.format(output[prediction[0]]))
    else:
        return render_template('main.html')

if __name__ == "__main__":
    app.run(debug=True)